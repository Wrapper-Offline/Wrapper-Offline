This directory contains third-party libraries used by utilikit.

Contents:

* [python-unidiff](//github.com/matiasb/python-unidiff)
    * For parsing and modifying unified diffs.
* [schema](//github.com/keleshev/schema)
    * For validating more sophisticated files such as INIs
