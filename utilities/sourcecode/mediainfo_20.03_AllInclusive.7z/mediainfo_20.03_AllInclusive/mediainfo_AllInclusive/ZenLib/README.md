# ZenLib README

Small C++ derivate classes to have an easier life

[![Build Status](https://travis-ci.org/MediaArea/ZenLib.svg?branch=master)](https://travis-ci.org/MediaArea/ZenLib)
[![Build status](https://ci.appveyor.com/api/projects/status/9tsuhfnk3svklj1m?svg=true)](https://ci.appveyor.com/project/MediaArea/zenlib/branch/master)

ZenLib - https://github.com/MediaArea/ZenLib  
Copyright (c) MediaArea.net SARL. All Rights Reserved.

This program is freeware under zlib license conditions.
See License.txt for more information
