* **Browser**:
* **Operating System**:
* **Stylus Version**:
* **Screenshot**:

<!--
Please make sure you checked that your issue wasn't already addressed.
If the issue persists, please help us identifying the cause by providing the above details.
-->
