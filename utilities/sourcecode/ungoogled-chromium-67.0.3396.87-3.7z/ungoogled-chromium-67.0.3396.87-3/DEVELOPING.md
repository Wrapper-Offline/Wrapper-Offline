# Development notes and procedures

The [GitHub Wiki](//github.com/Eloston/ungoogled-chromium/wiki) contains some additional information that changes more frequently.

## Adding command-line flags and `chrome://flags` options

See `docs/how_to_add_your_feature_flag.md` in the Chromium source tree for the steps needed. Note that updating `tools/metrics/histograms/enums.xml` is not required.

For new flags, first add a constant to `third_party/ungoogled/ungoogled_switches.cc` (by modifying patch `resources/patches/ungoogled-chromium/add-third-party-ungoogled.patch`). Then, use this constant in the steps outlined above.

## Notes on updating base bundles

To develop a better understanding of base bundles, have a look through [DESIGN.md](DESIGN.md) *and* the existing base bundles. Reading only DESIGN.md may make it difficult to develop intuition of the configuration system, and only exploring existing base bundles may not lead you to the whole picture.

Anytime the base bundles or patches are modified, use `developer_utilities/validate_config.py` to run several sanity checking algorithms.

## Workflow of updating patches

Tested on Debian 9.0 (stretch). Exact instructions should work on any other Linux or macOS system with the proper dependencies.

It is recommended to read the [BUILDING.md](BUILDING.md) and [DESIGN.md](DESIGN.md) documents first to gain a deeper understanding of the process.

### Dependencies

* [`quilt`](http://savannah.nongnu.org/projects/quilt)
    * This is available in most (if not all) Linux distributions, and also Homebrew on macOS.
    * This utility facilitates most of the updating process, so it is important to learn how to use this. The manpage for quilt (as of early 2017) lacks an example of a workflow. There are multiple guides online, but [this guide from Debian](https://wiki.debian.org/UsingQuilt) and [the referenced guide on that page](https://raphaelhertzog.com/2012/08/08/how-to-use-quilt-to-manage-patches-in-debian-packages/) are the ones referenced in developing the current workflow.
* Python 3.5 or newer

#### Steps for initial update

This is an example workflow on Linux that can be modified for your specific usage.

### Downloading the source code and updating lists

The utility `developer_utilities/update_lists.py` automates this process. By default, it will update the `common` base bundle automatically. Pass in `-h` or `--help` for availabe options.

Here's an example for updating the `common` configuration type:

```
mkdir -p buildspace/downloads
./developer_utilities/update_lists.py --auto-download
```

#### Updating patches

**IMPORTANT**: Make sure domain substitution has not been applied before continuing. Otherwise, the resulting patches will require domain substitution.

1. Setup a buildspace tree without domain substitution. For the `common` base bundle: `./buildkit-launcher.py getsrc -b common`
2. Generate a temporary patch order list for a given base bundle. For the `common` base bundle: `developer_utilities/generate_patch_order.py common`
3. Run `source $ROOT/developer_utilities/set_quilt_vars.sh`
    * This will setup quilt to modify patches directly in `resources/`
4. Use `quilt` to update the patches from the buildspace tree. The general procedure is as follows:
    1. Make sure all patches are unapplied: `quilt pop -a`. Check the status with `quilt top`
    2. Refresh patches that have fuzz or offsets until the first patch that can't apply: `while quilt push; do quilt refresh; done`
    3. If an error occurs, do `quilt push -f`
    4. Edit the broken files as necessary by adding (`quilt edit ...` or `quilt add ...`) or removing (`quilt remove ...`) files as necessary
        * When removing large chunks of code, remove each line instead of using language features to hide or remove the code. This makes the patches less susceptible to breakages when using quilt's refresh command (e.g. quilt refresh updates the line numbers based on the patch context, so it's possible for new but desirable code in the middle of the block comment to be excluded.). It also helps with readability when someone wants to see the changes made based on the patch alone.
    5. Refresh the patch: `quilt refresh`
    6. Go back to Step 2, and repeat this process until all of the patches have been fixed.
    7. Run `developer_utilities/validate_config.py` to do a sanity check of the patches and patch order.

This should leave unstaged changes in the git repository to be reviewed, added, and committed.

If you used `quilt new` anywhere during the update process, remember to add that patch manually to the corresponding `patch_order.list` for the applicable base bundle.

### Steps for fixing patches after a failed build attempt

If domain substitution is not applied, then the steps from the previous section (steps 2-6) will work for revising patches.

If domain substitution is applied, then the steps for the initial update will not apply since that would create patches which depend on domain substitution (which is undesirable for use cases that don't use domain substitution). Here is a method of dealing with this:

1. Use quilt to update the domain-substituted copy of the patch set
2. Copy back modified patches to the repository after reverting domain substitution on the patches manually
3. Run `developer_utilities/invert_domain_substitution.py` to invert the patches by specifying the proper base bundle.
3. Attempt a build.
4. Repeat entire procedure if there is a failure.
