[**The FAQ has moved to the new Wiki**](https://ungoogled-software.github.io/ungoogled-chromium-wiki/faq)
