// LockedStream.h

#ifndef __LOCKED_STREAM_H
#define __LOCKED_STREAM_H

#endif
